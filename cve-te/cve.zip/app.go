package main

import (
	"fmt"
	"log"
	"net/http"
	"net/http/httputil"
)

func handler(w http.ResponseWriter, r *http.Request) {

	fmt.Fprintln(w, "1-###################################")
	requestDump, _ := httputil.DumpRequest(r, true)
	fmt.Fprintf(w, "Response: %+v\nRequest: %+v\n\n", w, r)
	fmt.Fprintln(w, string(requestDump))
	fmt.Fprintln(w, "2-###################################")
}

func main() {
	http.HandleFunc("/", handler)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
