#!/bin/bash

# timeout 1s nc localhost 80 <Vanilla-Traefik-smuggle-req.txt
timeout 1s nc localhost 80 <req-cl.txt
