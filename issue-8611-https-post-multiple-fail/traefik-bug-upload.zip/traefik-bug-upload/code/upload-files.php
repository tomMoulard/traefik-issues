<?php
// You can simulate request time process here to add some more process time
//sleep(rand(2,7));

echo $_GET['i'];
