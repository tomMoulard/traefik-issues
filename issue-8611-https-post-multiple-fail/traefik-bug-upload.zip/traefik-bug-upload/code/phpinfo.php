<?php
// Can be called with url "/phpinfo.php" url, can give some information on the request for protocol scheme, port, etc. to control backend request is well done in https/443
phpinfo();
