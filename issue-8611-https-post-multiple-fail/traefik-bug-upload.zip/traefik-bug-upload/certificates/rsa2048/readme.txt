Generated with:
openssl req -new -newkey rsa:2048 -sha256 -days 365 -nodes -x509 -subj '/CN=localhost' -keyout certificate.key -out certificate.crt
